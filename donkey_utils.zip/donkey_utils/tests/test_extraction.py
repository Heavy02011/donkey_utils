import unittest

class TestExtraction(unittest.TestCase):
    def test_extract_all_zips(self):
        pass

    def test_extract_all_gzs(self):
        pass

    def test_extract_all_tar_gzs(self):
        pass

if __name__ == '__main__':
    unittest.main()
